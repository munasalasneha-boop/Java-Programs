import java.util.*;
public class pattern1 {
    public static void main(String[] args){
    int n=4;
    int num=1;
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=i;j++) {
        System.out.println(num+"");
        num++;
    }
    System.out.println();
    }
    }
}
    