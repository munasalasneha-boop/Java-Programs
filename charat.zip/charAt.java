import java.util.*;
public class charAt
{
	public static void main(String[] args) {
	    String s="java";
		System.out.println(s.charAt(3));
	}
}
