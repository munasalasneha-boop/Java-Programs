import java.util.*;
public class Student
{
    int id;
    String name;
    Student(int i,String n)
    {
        this.id=i;
        this.name=n;
    }
    void display()
    {
        System.out.println(id+""+name);
    }
    public static void main(String args[])
    {
        Student s1=new Student(101,"Sneha");
        s1.display();
    }
}